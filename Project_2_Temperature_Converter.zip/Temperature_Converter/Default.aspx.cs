﻿using System;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnFtoC_Click(object sender, EventArgs e)
    {
        decimal degreesF, degreesC;

        if (decimal.TryParse(tbFahrenheit.Text, out degreesF))
        {
            degreesC = (degreesF - 32.0M) * 5M / 9M;
            tbCelsius.Enabled = true;
            tbCelsius.Text = degreesC.ToString("0.0");
        }
        else
        {
            lblErrorMessage.Text = "Invalid value for Fahrenheit";
        }
        tbCelsius.Enabled = false;
        tbFahrenheit.Enabled = false;
        btnCtoF.Enabled = false;
        btnFtoC.Enabled = false;
    }

    protected void btnCtoF_Click(object sender, EventArgs e)
    {
        decimal degreesF, degreesC;

        if (decimal.TryParse(tbCelsius.Text, out degreesC))
        {
            degreesF = degreesC * 9.0M / 5.0M + 32.0M;
            tbFahrenheit.Enabled = true;
            tbFahrenheit.Text = degreesF.ToString("0.0");
        }
        else
        {
            lblErrorMessage.Text = "Invalid value for Celsius";
         }
        tbCelsius.Enabled = false;
        tbFahrenheit.Enabled = false;
        btnCtoF.Enabled = false;
        btnFtoC.Enabled = false;
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        tbFahrenheit.Text = "";
        tbCelsius.Text = "";
        lblErrorMessage.Text = "";
        tbCelsius.Enabled = true;
        tbFahrenheit.Enabled = true;
        btnCtoF.Enabled = true;
        btnFtoC.Enabled = true;
    }
}