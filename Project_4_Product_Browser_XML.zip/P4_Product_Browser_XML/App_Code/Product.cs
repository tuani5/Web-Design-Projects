using System;

public class Product
{
    private int id;
    private string category;
    private string subcategory;
    private string description;
    private decimal price;
    
    public int Id
    {
        get { return id; }
    }

    public String Category
    {
        get { return category; }
    }

    public String Subcategory
    {
        get { return subcategory; }
    }

    public String Description
    {
        get { return description; }
    }

    public Decimal Price
    {
        get { return price; }
    }

	public Product(int ID, 
        string Category,
        string Subcategory,
        string Description,
        decimal Price)
	{
        id = ID;
        category = Category;
        subcategory = Subcategory;
        description = Description;
        price = Price;
	}
}
