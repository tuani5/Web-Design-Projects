using System;
using System.Data;
using System.Web.UI.WebControls;
using System.Xml;
using System.Collections.Generic;

public partial class _Default : System.Web.UI.Page
{
    public List<Product> products;

    private void Setup_Categories_Dropdown_List()
    {
        List<String> categories = new List<String>();


        foreach (Product p in products)
        {
            bool category_found = false;
            foreach (String category in categories)
            {
                if (category == p.Category)
                {
                    category_found = true;
                    break;
                }
            }
            if (!category_found)
            {
                categories.Add(p.Category);
            }
        }

        // categories is now a list of all categories in the XML file
        ddlCategory.Items.Clear();
        ddlCategory.Items.Add(new ListItem("Please select category", ""));
        foreach (String category in categories)
        {
            // Add an item to ddlCategories
            ListItem li = new ListItem(category, category);
            ddlCategory.Items.Add(li);
        }
    }


    private void Setup_Subcategories_Dropdown_List(String selected_category)
    {
        List<String> subcategories = new List<String>();

        foreach (Product p in products)
        {
            if (p.Category != selected_category)
            {
                continue;
            }

            bool subcategory_found = false;
            foreach (String subcategory in subcategories)
            {
                if (subcategory == p.Subcategory)
                {
                    subcategory_found = true;
                    break;
                }
            }
            if (!subcategory_found)
            {
                subcategories.Add(p.Subcategory);
            }
        }

        // subcategories is now a list of all subcategories for 
        // the selected category.
        ddlSubcategory.Items.Clear();
        ddlSubcategory.Items.Add(new ListItem("Please select subcategory", ""));
        foreach (String subcategory in subcategories)
        {
            // Add an item to ddlCategories
            ListItem li = new ListItem(subcategory, subcategory);
            ddlSubcategory.Items.Add(li);
        }
        ddlSubcategory.Enabled = true;
        ddlSubcategory.Visible = true;
    }

    private void Setup_Products_Dropdown_List2(List<Product> products2)
    {
        ddlProduct.Items.Clear();
        ddlProduct.Items.Add(new ListItem("Please select product", ""));
        foreach (Product p in products2)
        {
            // Add an item to ddlProduct
            ListItem li = new ListItem(p.Description, p.Description);
            ddlProduct.Items.Add(li);
        }
        ddlProduct.Enabled = true;
    }


    // This function is used to set up the Products Dropdown List
    // for categories that have no subcategories.
    private void Setup_Products_Dropdown_List(String selected_category)
    {
        List<Product> products2 = new List<Product>();

        foreach (Product p in products)
        {
            if (p.Category != selected_category)
            {
                continue;
            }

            products2.Add(p);
        }
        Setup_Products_Dropdown_List2(products2);
    }


    // This function is used to set up the Products Dropdown List
    // for categories that have subcategories.
    private void Setup_Products_Dropdown_List(String selected_category,
                                              String selected_subcategory)
    {
        List<Product> products2 = new List<Product>();

        foreach (Product p in products)
        {
            if ((p.Category != selected_category) ||
                (p.Subcategory != selected_subcategory))
            {
                continue;
            }

            products2.Add(p);
        }

        Setup_Products_Dropdown_List2(products2);
    }


    protected void Page_Load(object sender, EventArgs e)
    {
        products = (List<Product>)Application["products"];

        if (!IsPostBack)
        {
            Setup_Categories_Dropdown_List();
            ddlCategory.Enabled = true;
            ddlSubcategory.Enabled = false;
            ddlProduct.Enabled = false;
        }
    }

    private Product Find_Product(String description)
    {
        foreach (Product p in products)
        {
            if (p.Description == description)
            {
                return p;
            }
        }
        return null;
    }

    protected void ddlCategory_SelectedIndexChanged1(object sender, EventArgs e)
    {
        if (ddlCategory.SelectedIndex == 0)
        {
            return;
        }
        String selected_category = ddlCategory.SelectedItem.Text;

        Setup_Subcategories_Dropdown_List(selected_category);

        if (ddlSubcategory.Items.Count < 3)
        {
            // This category has no subcategories.
            Setup_Products_Dropdown_List(selected_category);
            ddlSubcategory.Enabled = false;
            ddlSubcategory.Visible = false;
            lblSubcategory.Text = "N/A";
        }
        else
        {
            // This category has subcategories.
            ddlProduct.Items.Clear();
            ddlProduct.Enabled = false;

            lblCategory.Text = selected_category;
            lblSubcategory.Text = "";

        }
        lblProduct.Text = "";
        tbDescription.Text = "";
        tbPrice.Text = "";
        tbProductID.Text = "";
    }

    protected void ddlSubcategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCategory.SelectedIndex == 0)
        {
            return;
        }
        String selected_subcategory = ddlSubcategory.SelectedItem.Text;

        Setup_Products_Dropdown_List(lblCategory.Text, selected_subcategory);

        lblSubcategory.Text = selected_subcategory;
        lblProduct.Text = "";

        tbDescription.Text = "";
        tbPrice.Text = "";
        tbProductID.Text = "";
    }

    protected void ddlProduct_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlProduct.SelectedIndex == 0)
        {
            return;
        }

        String selected_product = ddlProduct.SelectedItem.Text;
        lblProduct.Text = selected_product;

        Product p = Find_Product(selected_product);

        if (p == null)
        {
            tbDescription.Text = "Product not found";
            tbPrice.Text = "";
            tbProductID.Text = "";
        }
        else
        {
            tbDescription.Text = p.Description;
            tbPrice.Text = p.Price.ToString();
            tbProductID.Text = p.Id.ToString();
        }
    }
}

