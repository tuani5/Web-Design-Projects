﻿using System;
using System.Data.SqlClient;

public partial class Ajax_Responder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string url = Request.QueryString["image_src"];

        int pos = url.IndexOf("/images/");
        string virtual_path = url.Substring(pos+1,url.Length-pos-1);
        string physical_path = Server.MapPath(virtual_path);

        System.Drawing.Image img = System.Drawing.Image.FromFile(physical_path);

        int width = (int)img.Width;
        int height = (int)img.Height;

        string reply = "{ \"url\":" + "\"" + url + "\", \"width\": \"" + width.ToString() + 
                         "\", \"height\": \"" + height.ToString() + "\" }";
        Response.Write(reply);
    }
}
