﻿using System;
using System.IO;
using System.Web.UI.WebControls;

public static class Files
{
    private static string uploadDirectory;

    public static string UploadDirectory
    {
        set { uploadDirectory = value; }
    }

    public static void Do_Upload(FileUpload FileUpload1, out string error_msg)
    {
        error_msg = "";
        if (FileUpload1.PostedFile.FileName == "")
        {
            error_msg = "No file specified";
            return;
        }

        string extension = Path.GetExtension(FileUpload1.PostedFile.FileName);

        switch (extension.ToLower())
        {
            case ".bmp":
            case ".gif":
            case ".jpg":
                break;
            default: error_msg = "This file type is not allowed";
                return;
        }

        string serverFileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
        string Full_Upload_Path = Path.Combine(uploadDirectory, serverFileName);
         try
        {
            FileUpload1.PostedFile.SaveAs(Full_Upload_Path);
            string query_error_msg =
                Query.Add_File_to_Database("images/" + serverFileName);
        }
        catch (Exception ex)
        {
            error_msg = ex.Message;
            return;
        }


    }

    public static void Delete_Unused_Files(string dir, out string error_msg)
    {
        error_msg = "";
        int file_count = Query.Count_Files();

        while (file_count > 5)
        {
            string oldest_file_name = "";
            string error_msg2 = "";
            Query.Delete_Oldest_File_Name(out oldest_file_name, out error_msg2);
            file_count--;
            if (error_msg2.Length > 0)
            {
                error_msg = "Error deleting unused files: " + error_msg2;
                return;
            }

            string Full_Path = Path.Combine(dir, oldest_file_name);

            try
            {
                File.Delete(Full_Path);
            }
            catch (Exception ex)
            {
                error_msg = "Error deleting unused files: " + ex.Message;
                return;
            }
        }

    }

}