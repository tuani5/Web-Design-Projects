﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


public static class Query
{

    public static string Add_File_to_Database(string filename)
    {
        SqlConnection cn = null;
        string error_msg = "";
        try
        {
            cn = Setup_Connection();
            error_msg = Execute_Command(cn, filename);
        }
        catch (Exception ex)
        {
            error_msg = "ERROR: " + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }
        return error_msg;
    }


    private static SqlConnection Setup_Connection()
    {
        String connection_string =
WebConfigurationManager.ConnectionStrings["wpusr40"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;
    }

    private static string Execute_Command(SqlConnection cn, string filename)
    {
        string error_msg = "";
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "INSERT INTO Photo_File_Names " +
                          "VALUES (@Filename) ";

        cmd.Parameters.AddWithValue("@Filename", filename);
        cmd.Connection = cn;
        int nr_rows = cmd.ExecuteNonQuery();
        if (nr_rows != 1)
        {
            error_msg = "Number of rows affect = " + nr_rows;
        }
        return error_msg;
    }


    public static int Count_Files()
    {
        SqlConnection cn = null;
        int file_count = 0;
        try
        {
            cn = Setup_Connection();
            file_count = Execute_Count_Command(cn);
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }
        return file_count;
    }

    private static int Execute_Count_Command(SqlConnection cn)
    {
        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Photo_File_Names";
        cmd.Connection = cn;
        int count = (int) cmd.ExecuteScalar();
        return count;
    }

    public static void Delete_Oldest_File_Name(out string file_name,
                                               out string error_msg)
    {
        error_msg = "";
        file_name = "";
        int min_id = 0;
        SqlConnection cn = null;
        try
        {
            cn = Setup_Connection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandText = "SELECT MIN(ID) FROM Photo_File_Names ";
            min_id = (int)cmd.ExecuteScalar();

            cmd.CommandText = "SELECT File_Name FROM Photo_File_Names " +
                              "WHERE ID=" + min_id;
            file_name = (string) cmd.ExecuteScalar();

            cmd.CommandText = "DELETE FROM Photo_File_Names " +
                              "WHERE ID=" + min_id;
            int nr_rows = cmd.ExecuteNonQuery();
            if (nr_rows != 1)
            {
                error_msg = "Number of rows affected by delete = " + nr_rows;
            }
        }
        catch (Exception ex)
        {
            error_msg += ex.Message;
        }
        finally
        {
            if (cn != null) cn.Close();
        }
    }
}