﻿using System;
using System.Configuration;
using System.Web.UI.WebControls;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack)
        {
            lblMessage.Text = "";
        }
        else
        {
            //Files.UploadDirectory = Path.Combine(Request.PhysicalApplicationPath, "images");
            Files.UploadDirectory = Server.MapPath("images");
        }
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        string error_msg = "";

        Files.Do_Upload(FileUpload1, out error_msg);
        if (error_msg.Length > 0)
        {
            lblMessage.Text = error_msg;
            return;
        }

        string website_directory = Server.MapPath("~/");
        Files.Delete_Unused_Files(website_directory, out error_msg);
        if (error_msg.Length > 0)
        {
            lblMessage.Text = error_msg;
            return;
        }


        Response.Redirect("Start.aspx");
    } 
}
