﻿$(document).ready( function() {
    $('input').bind('click', get_image_size);
    $('#FileUpload1').unbind('click');
    $('#btnUpload').unbind('click');
    $('input.thumbnail').trigger('click');
});


function get_image_size(evt) {
    evt.preventDefault();
    
    if (!evt.currentTarget.src) return;
    if (evt.currentTarget.src.length < 1) return;
    
    $.get('Ajax_Responder.aspx',
          'image_src='+evt.currentTarget.src,
           update_large_image);
}

function update_large_image(result, status)
{
    var obj = jQuery.parseJSON(result);
    
    var width = obj.width;
    var height = obj.height;
    var aspect_ratio = width / height;
    
    if (aspect_ratio < 1.0)
    {
        $('#full_image').css('width', 600*aspect_ratio);
        $('#full_image').css('height',600);
    }
    else{
        $('#full_image').css('width',600);
        $('#full_image').css('height', 600 / aspect_ratio);
    }

    $('#full_image')[0].src = obj.url;
}