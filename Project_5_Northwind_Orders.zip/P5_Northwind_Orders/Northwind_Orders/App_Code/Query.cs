﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web.Configuration;
using System.Web.UI.WebControls;

public static class Query
{
    public static List<Customer> Get_Customers(string abrev, out string error_msg)
    {
        List<Customer> customers = new List<Customer>();
   
        SqlDataReader rdr = null;
        SqlConnection cn = null;
        error_msg = "";
        try
        {
            cn = Setup_Connection();
            rdr = Get_Reader(abrev, cn);

            while (rdr.Read())
            {
                Customer customer = new Customer(rdr);
                customers.Add(customer);
            }
            
        }
        catch (Exception ex)
        {
            error_msg = "ERROR: " + ex.Message;
        }
        finally
        {
            if (rdr != null)
            {
                rdr.Close();
            }

            if (cn != null)
            {
                cn.Close();
            }
        }
        return customers;
    }

    private static SqlConnection Setup_Connection()
    {
        String connection_string =
WebConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;

        SqlConnection cn = new SqlConnection(connection_string);

        cn.Open();
        return cn;
    }

    private static SqlDataReader Get_Reader(string abrev,
                                            SqlConnection cn)
    {
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "SELECT * FROM Customers " +
                          "WHERE CompanyName LIKE @abrev";

        cmd.Parameters.AddWithValue("@abrev", abrev+"%");

        cmd.Connection = cn;
        return cmd.ExecuteReader();
    }


    public static void Populate_DropDownList(DropDownList ddlCustomer, 
                                             List<Customer> customers)
    {
        ddlCustomer.Items.Clear();
        ListItem li;

        if (customers.Count > 1)
        {
            li = new ListItem("Select Customer", "Select Customer");
        }
        else
        {
            li = new ListItem("", "");
        }
        ddlCustomer.Items.Add(li);

        foreach (Customer customer in customers)
        {
            li = new ListItem(customer.Name, customer.Id);
            ddlCustomer.Items.Add(li);
        }
    }

    
    public static int Count_Orders(string Customer_ID, out string error_msg)
    {
        SqlConnection cn = null;
        error_msg = "";
        int count = 0;
        try
        {
            cn = Setup_Connection();
            count = Count_Orders2(cn, Customer_ID);
        }
        catch (Exception ex)
        {
            error_msg = "ERROR: " + ex.Message;
        }
        finally
        {
            if (cn != null)
            {
                cn.Close();
            }
        }
        return count;
    }

    private static int Count_Orders2(SqlConnection cn, string Customer_ID)
    {
        SqlCommand cmd = new SqlCommand();

        cmd.CommandText = "SELECT COUNT(*) FROM Orders " +
                          "WHERE CustomerID=@CustomerID";

        cmd.Parameters.AddWithValue("@CustomerID", Customer_ID);
        cmd.Connection = cn;
        int count = (int) cmd.ExecuteScalar();
        return count;
    }
}
