﻿using System;
using System.Data.SqlClient;

public class Customer
{
    string id;
    string name;

    public string Id
    {
        get { return id; }
    }
    public string Name
    {
        get { return name; }
    }

	public Customer(SqlDataReader rdr)
	{
        id = (string)rdr["customerID"];
        name = (string)rdr["CompanyName"];
	}


}
