﻿using System;
using System.Collections.Generic;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        lblErrorMessage1.Text = "";
        lblErrorMessage2.Text = "";
        if (!IsPostBack)
        {
            tbName.Focus();
        }
    }

    protected void tbName_TextChanged(object sender, EventArgs e)
    {
        string error_msg1 = "";
        string error_msg2 = "";
        string name_abrev = tbName.Text.Trim();
        lblMessage.Text = "";
        ddlCustomer.Items.Clear();
        ddlCustomer.Enabled = false;

        if (name_abrev.Length == 0)
        {
            return;
        }

        List<Customer> customers = Query.Get_Customers(name_abrev, out error_msg1);

        if (customers.Count == 0)
        {
            lblMessage.Text = "There are no customer names matching " + name_abrev;
        }
        else if (customers.Count == 1)
        {
            Customer customer = customers[0];
            int count = Query.Count_Orders(customer.Id, out error_msg2);
            lblMessage.Text = customer.Name + " has " + count + " orders";
        }
        else
        {
            Query.Populate_DropDownList(ddlCustomer, customers);
            ddlCustomer.Enabled = true;
        }
        lblErrorMessage1.Text = error_msg1;
        lblErrorMessage2.Text = error_msg2;
    }

    protected void ddlCustomer_SelectedIndexChanged(object sender, EventArgs e)
    {
        string error_msg = "";
        if (ddlCustomer.SelectedIndex == 0)
        {
            return;
        }

        int count = Query.Count_Orders(ddlCustomer.SelectedValue, out error_msg);
        lblMessage.Text = ddlCustomer.SelectedItem + " has " + count + " orders";
        lblErrorMessage1.Text = error_msg;
    }
}
